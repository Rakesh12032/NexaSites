# 🚀 NexaSites — Full Stack Web Design Agency
**Founded by Rakesh Kumar | Saharsa, Bihar 852201**

---

## 📁 Project Structure

```
nexasites/
├── server.js          ← Main Express server
├── package.json       ← Dependencies
├── .env.example       ← Environment variables template
├── db.json            ← Auto-generated database (JSON)
├── routes/
│   ├── bookings.js    ← Booking API (POST/GET/PATCH/DELETE)
│   └── auth.js        ← Admin login API
├── middleware/
│   └── auth.js        ← JWT verification
└── public/
    └── index.html     ← Complete frontend (served by Express)
```

---

## ⚡ Local Setup (Windows/Mac/Linux)

### Step 1 — Node.js install karo
👉 https://nodejs.org → LTS version download karo

### Step 2 — Project folder mein jaao
```bash
cd nexasites
```

### Step 3 — .env file banao
```bash
copy .env.example .env        # Windows
# ya
cp .env.example .env          # Mac/Linux
```

### Step 4 — .env file edit karo (Notepad/VSCode)
```
ADMIN_PASSWORD=nexasites2025
JWT_SECRET=kuch_bhi_random_likho_yahan
EMAIL_USER=rakeshraj18052@gmail.com
EMAIL_PASS=GMAIL_APP_PASSWORD_YAHAN
```

### Step 5 — Dependencies install karo
```bash
npm install
```

### Step 6 — Server start karo
```bash
npm start
```

### Step 7 — Browser mein kholo
```
http://localhost:3000
```

---

## 🌐 Free Deployment — Railway.app (Recommended)

### Step 1 — GitHub pe upload karo
1. github.com pe account banao
2. New repository: `nexasites`
3. Sab files upload karo

### Step 2 — Railway.app pe deploy karo
1. railway.app jaao → Login with GitHub
2. "New Project" → "Deploy from GitHub repo"
3. `nexasites` select karo
4. **Environment Variables add karo:**
   ```
   ADMIN_PASSWORD = nexasites2025
   JWT_SECRET = any_random_string_here
   EMAIL_USER = rakeshraj18052@gmail.com
   EMAIL_PASS = your_gmail_app_password
   NOTIFY_EMAIL = rakeshraj18052@gmail.com
   ```
5. Deploy! 🚀 Live URL milega jaise: `nexasites.up.railway.app`

**Railway Free Plan:** 500 hours/month — kaafi hai!

---

## 📧 Gmail Email Setup

Real emails bhejne ke liye:

1. Gmail → Settings → Security
2. **2-Step Verification** ON karo
3. Settings → Security → **App Passwords**
4. App: "Mail", Device: "Windows Computer"
5. 16-character password milega → `.env` mein `EMAIL_PASS` mein daalo

---

## 🔐 Admin Panel Access

1. Website pe **"Admin"** link click karo (bottom-right of navbar)
2. Password: `nexasites2025` (ya jo .env mein set kiya)
3. Dashboard mein:
   - ✅ Saari bookings real-time dikhti hain
   - ✅ Status change: New → Contacted → Closed
   - ✅ WhatsApp direct message button
   - ✅ Email client button
   - ✅ Delete booking
   - ✅ CSV Export (Excel)

---

## 💳 Payment Receive (India se US/AU clients)

| Method | Best For | Fees |
|--------|----------|------|
| **Wise** | Bank transfer USD/AUD→INR | ~0.5% |
| **PayPal** | Quick, universal | ~3-4% |
| **Payoneer** | Freelancers | ~2% |

---

## 📞 Contact
- **Founder:** Rakesh Kumar
- **Phone:** +91 7667844210
- **Email:** rakeshraj18052@gmail.com
- **Address:** Saharsa, Bihar — 852201, India
- **LinkedIn:** linkedin.com/in/rakesh-kumar-0aa983210
