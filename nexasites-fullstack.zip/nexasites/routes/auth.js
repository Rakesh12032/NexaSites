const router = require('express').Router();
const jwt = require('jsonwebtoken');

// POST /api/auth/login
router.post('/login', (req, res) => {
  const { password } = req.body;
  const correctPwd = process.env.ADMIN_PASSWORD || 'nexasites2025';

  if (password !== correctPwd) {
    return res.status(401).json({ error: 'Incorrect password' });
  }

  const token = jwt.sign(
    { admin: true, name: 'Rakesh Kumar' },
    process.env.JWT_SECRET || 'nexasites_secret',
    { expiresIn: '24h' }
  );

  res.json({ token, admin: 'Rakesh Kumar', message: 'Login successful' });
});

module.exports = router;
