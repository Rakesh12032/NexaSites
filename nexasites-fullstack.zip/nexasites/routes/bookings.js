const router = require('express').Router();
const nodemailer = require('nodemailer');
const authMiddleware = require('../middleware/auth');

// ── EMAIL TRANSPORTER ──
function getTransporter() {
  return nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });
}

async function sendEmails(booking) {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS || process.env.EMAIL_PASS === 'your_gmail_app_password_here') {
    console.log('📧 Email not configured — skipping email send');
    return;
  }
  const transporter = getTransporter();

  // 1. Notify admin (Rakesh)
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || process.env.EMAIL_USER,
      to: process.env.NOTIFY_EMAIL || process.env.EMAIL_USER,
      subject: `🔔 New Demo Request — ${booking.biz} (${booking.country})`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#0a0a0a;color:#f5f5f5;border-radius:12px;overflow:hidden">
          <div style="background:#bfff58;padding:20px 30px">
            <h2 style="color:#000;margin:0;font-size:1.3rem">🎯 New Demo Request!</h2>
          </div>
          <div style="padding:30px">
            <table style="width:100%;border-collapse:collapse">
              <tr><td style="padding:8px 0;color:#666;width:130px">Name</td><td style="color:#fff;font-weight:bold">${booking.name}</td></tr>
              <tr><td style="padding:8px 0;color:#666">Business</td><td style="color:#fff">${booking.biz}</td></tr>
              <tr><td style="padding:8px 0;color:#666">Email</td><td><a href="mailto:${booking.email}" style="color:#bfff58">${booking.email}</a></td></tr>
              <tr><td style="padding:8px 0;color:#666">Phone</td><td><a href="https://wa.me/${booking.phone?.replace(/\D/g,'')}" style="color:#bfff58">${booking.phone || '—'}</a></td></tr>
              <tr><td style="padding:8px 0;color:#666">Niche</td><td style="color:#bfff58">${booking.type}</td></tr>
              <tr><td style="padding:8px 0;color:#666">Country</td><td style="color:#fff">${booking.country}</td></tr>
              <tr><td style="padding:8px 0;color:#666">Website</td><td style="color:#fff">${booking.currentUrl || '—'}</td></tr>
              <tr><td style="padding:8px 0;color:#666;vertical-align:top">Message</td><td style="color:#fff">${booking.msg || '—'}</td></tr>
            </table>
            <div style="margin-top:25px;padding-top:20px;border-top:1px solid #1e1e1e">
              <a href="https://wa.me/${booking.phone?.replace(/\D/g,'')}" style="display:inline-block;background:#25d366;color:#000;padding:10px 20px;border-radius:100px;text-decoration:none;font-weight:bold;font-size:0.85rem;margin-right:10px">💬 WhatsApp</a>
              <a href="mailto:${booking.email}" style="display:inline-block;background:#4a9eff;color:#000;padding:10px 20px;border-radius:100px;text-decoration:none;font-weight:bold;font-size:0.85rem">✉ Email Client</a>
            </div>
          </div>
        </div>
      `,
    });
    console.log('✅ Admin notification email sent');
  } catch (e) {
    console.error('❌ Admin email error:', e.message);
  }

  // 2. Confirmation to client
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || process.env.EMAIL_USER,
      to: booking.email,
      subject: `✅ Your Free Demo Request Received — NexaSites`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#0a0a0a;color:#f5f5f5;border-radius:12px;overflow:hidden">
          <div style="background:#bfff58;padding:20px 30px">
            <h2 style="color:#000;margin:0">🎉 Demo Request Received!</h2>
          </div>
          <div style="padding:30px">
            <p style="color:#888;font-size:0.95rem">Hi <strong style="color:#fff">${booking.name}</strong>,</p>
            <p style="color:#888;font-size:0.95rem">We've received your free demo request for <strong style="color:#bfff58">${booking.biz}</strong>!</p>
            <div style="background:#141414;border-radius:10px;padding:20px;margin:20px 0;border-left:3px solid #bfff58">
              <p style="color:#bfff58;font-weight:bold;margin:0 0 8px">What happens next?</p>
              <p style="color:#666;margin:0;font-size:0.9rem">⚡ We'll build your complete demo website within <strong style="color:#fff">72 hours</strong><br>📧 We'll send it to this email for your review<br>🔄 You get 3 free revision rounds<br>💰 Payment only after you approve — zero risk</p>
            </div>
            <p style="color:#888;font-size:0.9rem">For faster communication, WhatsApp us directly:</p>
            <a href="https://wa.me/917667844210" style="display:inline-block;background:#25d366;color:#000;padding:12px 24px;border-radius:100px;text-decoration:none;font-weight:bold">💬 WhatsApp: +91 7667844210</a>
            <p style="color:#333;font-size:0.8rem;margin-top:25px">Rakesh Kumar · Founder, NexaSites · Saharsa, Bihar 852201, India</p>
          </div>
        </div>
      `,
    });
    console.log('✅ Client confirmation email sent to', booking.email);
  } catch (e) {
    console.error('❌ Client email error:', e.message);
  }
}

// ── ROUTES ──

// POST /api/bookings — Submit new booking (public)
router.post('/', async (req, res) => {
  const { name, biz, email, phone, type, country, currentUrl, msg } = req.body;

  if (!name || !biz || !email || !type) {
    return res.status(400).json({ error: 'Name, business, email, and type are required.' });
  }
  if (!email.includes('@') || !email.includes('.')) {
    return res.status(400).json({ error: 'Please provide a valid email address.' });
  }

  const db = req.app.locals.db;
  const id = db.get('nextId').value();

  const booking = {
    id,
    name: name.trim(),
    biz: biz.trim(),
    email: email.trim().toLowerCase(),
    phone: phone?.trim() || '—',
    type,
    country: country || 'United States',
    currentUrl: currentUrl?.trim() || '—',
    msg: msg?.trim() || '—',
    status: 'New',
    createdAt: new Date().toISOString(),
  };

  db.get('bookings').unshift(booking).write();
  db.set('nextId', id + 1).write();

  // Send emails async (don't wait)
  sendEmails(booking);

  res.status(201).json({ success: true, message: 'Demo request submitted!', id });
});

// GET /api/bookings — Get all bookings (admin only)
router.get('/', authMiddleware, (req, res) => {
  const db = req.app.locals.db;
  const { status } = req.query;
  let bookings = db.get('bookings').value();
  if (status && status !== 'all') {
    bookings = bookings.filter(b => b.status === status);
  }
  const all = db.get('bookings').value();
  const stats = {
    total: all.length,
    new: all.filter(b => b.status === 'New').length,
    contacted: all.filter(b => b.status === 'Contacted').length,
    closed: all.filter(b => b.status === 'Closed').length,
    revenue: all.filter(b => b.status === 'Closed').length * 799,
  };
  res.json({ bookings, stats });
});

// PATCH /api/bookings/:id/status — Update status (admin only)
router.patch('/:id/status', authMiddleware, (req, res) => {
  const db = req.app.locals.db;
  const id = parseInt(req.params.id);
  const { status } = req.body;
  const valid = ['New', 'Contacted', 'Closed'];
  if (!valid.includes(status)) return res.status(400).json({ error: 'Invalid status' });

  const booking = db.get('bookings').find({ id }).value();
  if (!booking) return res.status(404).json({ error: 'Booking not found' });

  db.get('bookings').find({ id }).assign({ status }).write();
  res.json({ success: true, status });
});

// DELETE /api/bookings/:id — Delete booking (admin only)
router.delete('/:id', authMiddleware, (req, res) => {
  const db = req.app.locals.db;
  const id = parseInt(req.params.id);
  db.get('bookings').remove({ id }).write();
  res.json({ success: true });
});

module.exports = router;
